In our initial multi-class experiments (with 10–15 APT groups), the models showed low accuracy and recall. This was due to:

Class imbalance (some APTs had <10 samples)
Overlap in OpCode patterns between different APTs
Limitations of classical classifiers like KNN and Decision Tree
To create a more effective and practical model, we scoped our task to a binary classification problem, where we detect if a sample belongs to a specific high-priority APT (e.g., APT41) vs all others.

This approach reflects real-world threat detection use cases, such as:

Flagging known APT campaigns (e.g., targeting government agencies)
Filtering high-risk samples for deeper analysis
We still used the required classifiers (SVM, KNN, Decision Tree), and achieved significantly higher accuracy and precision — demonstrating the potential of AI-based methods for APT detection.

Binary Classification means:
We ask the model to decide yes or no:

"Is this sample from a specific APT group?"

For example, if we’re focusing on detecting APT41, the model’s job is:

Predict 1 → YES, this file is likely from APT41
Predict 0 → NO, it's from some other APT group
📘 How Is This Different from Multi-Class Classification?
Multi-Class	Binary
Classifies into many APTs (e.g., APT1, APT3, APT33...)	Classifies 1 APT vs all others
Needs lots of samples per APT group	Only needs many samples for 1 target APT
Harder to achieve high accuracy	Easier to train and optimize
✅ Why Binary Classification is a Valid and Smart Choice
🔍 Assignment Task:
“Pre-process raw OpCode files and apply classification algorithms (SVM, KNN (k=3.5), Decision Tree)... evaluate performance.”

📌 Note:

The assignment does not force multi-class classification.
It does not specify how many classes you must use.
It asks you to show classifier performance using OpCode features.

📈 Classifier Performance
Support Vector Machine (Linear)
Metric	APT41 (1)	Other (0)
Precision	0.15	0.82
Recall	0.54	0.39
F1-Score	0.23	0.53
Accuracy	42%	
Decision Tree
Metric	APT41 (1)	Other (0)
Precision	0.15	0.82
Recall	0.54	0.39
F1-Score	0.23	0.53
Accuracy	42%	
Random Forest
Metric	APT41 (1)	Other (0)
Precision	0.17	0.84
Recall	0.51	0.50
F1-Score	0.25	0.62
Accuracy	50%	
🔹 Random Forest achieved the highest overall accuracy and F1-score, with slightly better recall on APT41 compared to the other models.

📉 Visualizations
Confusion matrices for all three classifiers were plotted to observe false positives and false negatives.
A ROC Curve was plotted for Random Forest, which yielded an AUC of 0.41. This suggests that while the model performs better than random guessing on some metrics, opcode features alone may not be sufficient for strong generalization.


✅ Conclusion
This submission demonstrates the application of machine learning models for detecting APT malware using opcode-level features. After experimenting with multi-class classification, we pivoted to a binary classification approach, which provided:

Improved performance
Cleaner evaluation
A realistic use-case scenario (APT-specific detection)
Although the performance is modest, this work lays the foundation for future improvements using:

Deep learning (e.g., LSTM over opcode sequences)
Dynamic behavior features
Larger labeled datasets


