# Binary classification for APT41 vs Others

import os
import re
import pandas as pd
import joblib
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_selection import SelectKBest, chi2

# === CONFIG ===
opcode_folder = "OPCODES_2"
output_folder = "processed_dataset"
target_class = "APT41"
ngram_range = (1, 2)
max_features = 10000
select_k_best = 3000
random_seed = 42
test_size = 0.2
min_samples = 10

# === Label extractor ===
def extract_label(fname):
    match = re.match(r"([A-Za-z0-9]+)_", fname)
    return match.group(1) if match else "Unknown"

# === Load and clean data ===
documents, labels = [], []
for fname in os.listdir(opcode_folder):
    if fname.endswith(".opcode"):
        label = extract_label(fname)
        if label == "Unknown":
            continue
        try:
            with open(os.path.join(opcode_folder, fname), "r", encoding="utf-8", errors="ignore") as f:
                opcodes = " ".join(f.read().splitlines())
                documents.append(opcodes)
                labels.append(label)
        except:
            continue

# Filter out rare classes
counts = Counter(labels)
filtered = [(doc, lbl) for doc, lbl in zip(documents, labels) if counts[lbl] >= min_samples]
documents, labels = zip(*filtered)

# Binary label assignment
binary_labels = [1 if lbl == target_class else 0 for lbl in labels]

# Vectorization
vectorizer = CountVectorizer(ngram_range=ngram_range, max_features=max_features)
X = vectorizer.fit_transform(documents)

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, binary_labels, test_size=test_size, stratify=binary_labels, random_state=random_seed
)

# Feature selection
selector = SelectKBest(chi2, k=select_k_best)
X_train = selector.fit_transform(X_train, y_train)
X_test = selector.transform(X_test)

# Save artifacts
os.makedirs(output_folder, exist_ok=True)
joblib.dump(X_train, f"{output_folder}/X_train.pkl")
joblib.dump(X_test, f"{output_folder}/X_test.pkl")
pd.Series(y_train).to_csv(f"{output_folder}/y_train.csv", index=False)
pd.Series(y_test).to_csv(f"{output_folder}/y_test.csv", index=False)
joblib.dump(vectorizer, f"{output_folder}/vectorizer.pkl")
joblib.dump(selector, f"{output_folder}/selector.pkl")

print(f"[+] Binary preprocessing complete. Target class: {target_class} | Positives: {sum(binary_labels)} / {len(binary_labels)}")
