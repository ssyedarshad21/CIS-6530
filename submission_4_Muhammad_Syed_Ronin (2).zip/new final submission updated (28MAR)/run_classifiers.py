# run_classifiers.py (Binary - APT41 vs Others with Random Forest)

import joblib
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import svm
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay, roc_curve, auc

# === Load dataset ===
X_train = joblib.load("processed_dataset/X_train.pkl")
X_test = joblib.load("processed_dataset/X_test.pkl")
y_train = pd.read_csv("processed_dataset/y_train.csv").squeeze()
y_test = pd.read_csv("processed_dataset/y_test.csv").squeeze()

print("\nLabel distribution (y_test):")
print(y_test.value_counts())

# === Define models ===
models = {
    "SVM (Linear)": svm.SVC(kernel="linear", class_weight="balanced", probability=True),
    "Decision Tree": DecisionTreeClassifier(class_weight="balanced", random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=100, class_weight="balanced", random_state=42)
}

for name, model in models.items():
    print(f"\n=== Training {name} ===")
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1] if hasattr(model, "predict_proba") else None

    print(classification_report(y_test, y_pred, zero_division=0))

    cm = confusion_matrix(y_test, y_pred, labels=[0, 1])
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Other", "APT41"])
    disp.plot()
    plt.title(f"Confusion Matrix - {name}")
    plt.savefig(f"conf_matrix_{name.replace(' ', '_')}.png")
    plt.show()

    # ROC Curve
    if y_proba is not None:
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, label=f"{name} (AUC = {roc_auc:.2f})")

plt.plot([0, 1], [0, 1], "--", color="gray")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve - APT41 Detection")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("roc_curve_all_models.png")
plt.show()
