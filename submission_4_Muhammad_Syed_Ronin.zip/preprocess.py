import pandas as pd
import os

#Muhammad Zafar
#Syed Arshad
#Ronin Furtado

#Opcode directory
#Changed to universal as it cant depend on host machine

script_dir = os.path.dirname(os.path.abspath(__file__))
directory_path = os.path.join(script_dir, "OPCODES_2")  
output_path = os.path.join(script_dir, "extracted_opcodes.csv")  

#Store the info each file
sdf = []

#Iterate over the files in directory
for file_name in os.listdir(directory_path):

    if file_name.endswith('.opcode'):  

        apt_label = file_name.split("_")[0]   # first 10 chars is APT label

        fp = os.path.join(directory_path, file_name)
        
        # Read opcodes from the file

        with open(fp, 'r') as file:

            opcodes_list = [line.strip() for line in file if line.strip()]
        
        #opcodes are joined in one string

        opcode_string = ', '.join(opcodes_list)
        
        # Append to list

        sdf.append({

            'Opcodes': opcode_string,

            'APT': apt_label

        })

#DataFrame gets created
df = pd.DataFrame(sdf)

#Dataframe becomes a CSV
df.to_csv(output_path, index=False)

#Tell user where CSV file is made
print(f'CSV file created at: {output_path}')
