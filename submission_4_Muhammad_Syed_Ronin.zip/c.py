import os
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import RandomOverSampler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.feature_extraction.text import CountVectorizer

#Muhammad Zafar
#Syed Arshad
#Ronin Furtado

# Step 1: Extract opcode sequences and save to CSV
def extract_opcode_data(source_dir, output_file):
    dataset = []
    for file in os.listdir(source_dir):
        if file.endswith('.opcode'):
            label = file.split("_")[0]  # Extracts label from filename
            filepath = os.path.join(source_dir, file)
            with open(filepath, 'r') as f:
                opcode_sequence = ' '.join([line.strip() for line in f if line.strip()])
            dataset.append({'Opcodes': opcode_sequence, 'APT': label})
    pd.DataFrame(dataset).to_csv(output_file, index=False)
    print(f'Opcode dataset stored in: {output_file}')

# Step 2: Generate Features using N-grams
def generate_ngram_features(csv_file):
    df = pd.read_csv(csv_file)
    unigram_vectorizer = CountVectorizer(ngram_range=(1, 1), max_features=5000)
    bigram_vectorizer = CountVectorizer(ngram_range=(2, 2), max_features=5000)
    X_unigram = unigram_vectorizer.fit_transform(df['Opcodes'])
    X_bigram = bigram_vectorizer.fit_transform(df['Opcodes'])
    return X_unigram, X_bigram, df['APT']

# Step 3: Handle Class Imbalance with Oversampling
def apply_oversampling(X, y):
    sampler = RandomOverSampler()
    X_balanced, y_balanced = sampler.fit_resample(X, y)
    return X_balanced, y_balanced

# Step 4: Train and Assess Models
def train_models(X_train, X_test, y_train, y_test):
    models = {
        'Support Vector Machine': SVC(kernel='linear'),
        'K-Nearest Neighbors': KNeighborsClassifier(n_neighbors=3),
        'Decision Tree': DecisionTreeClassifier(),
        'Random Forest': RandomForestClassifier(n_estimators=200)
    }
    
    for model_name, clf in models.items():
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        print(f'\nPerformance Report - {model_name}:')
        print(classification_report(y_test, y_pred))
        matrix = confusion_matrix(y_test, y_pred)
        plt.figure(figsize=(6, 4))
        sns.heatmap(matrix, annot=True, fmt='d', cmap='Blues')
        plt.title(f'Confusion Matrix - {model_name}')
        plt.xlabel('Predicted')
        plt.ylabel('Actual')
        plt.show()

# Step 5: Optimize Random Forest with Grid Search
def optimize_rf(X_train, y_train):
    search_space = {
        'n_estimators': [100, 200],
        'max_depth': [10, 20, None],
        'min_samples_split': [2, 5, 10]
    }
    search = GridSearchCV(RandomForestClassifier(), search_space, cv=5)
    search.fit(X_train, y_train)
    print(f'Optimal Hyperparameters for Random Forest: {search.best_params_}')
    return search.best_estimator_

# Script Execution
if __name__ == '__main__':
    project_path = os.path.dirname(os.path.abspath(__file__))
    opcode_folder = os.path.join(project_path, "OPCODES_2") 
    opcode_csv = 'opcode_data.csv'
    
    extract_opcode_data(opcode_folder, opcode_csv)
    X_unigram, X_bigram, labels = generate_ngram_features(opcode_csv)
    
    X_balanced, y_balanced = apply_oversampling(X_unigram, labels)
    X_tr, X_te, y_tr, y_te = train_test_split(X_balanced, y_balanced, test_size=0.2, random_state=42)
    
    train_models(X_tr, X_te, y_tr, y_te)
    best_rf = optimize_rf(X_tr, y_tr)
    
    print("Model training finished! The top-performing Random Forest model has been stored.")
