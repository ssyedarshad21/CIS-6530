
import os
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.utils.multiclass import unique_labels
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, Conv1D, MaxPooling1D, LSTM, Concatenate, Dropout, Dense
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Load preprocessed data
DATA_DIR = 'opcode_encoded'
MAX_LEN = 1000

X = []
y = []

for filename in os.listdir(DATA_DIR):
    if filename.endswith('.npz'):
        data = np.load(os.path.join(DATA_DIR, filename))
        X.append(data['sequence'])
        y.append(data['label'])

X = pad_sequences(X, maxlen=MAX_LEN, padding='post')
y = np.array(y)

# Filter out classes with less than 2 samples
label_counts = Counter(y)
valid_indices = [i for i, label in enumerate(y) if label_counts[label] >= 2]
X = X[valid_indices]
y = y[valid_indices]

# Encode labels
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)
class_names = label_encoder.classes_

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, stratify=y_encoded, random_state=42)

# One-hot encode the targets
num_classes = len(np.unique(y_encoded))
y_train_cat = to_categorical(y_train, num_classes=num_classes)
y_test_cat = to_categorical(y_test, num_classes=num_classes)

# Define the CNN+LSTM model
input_layer = Input(shape=(X.shape[1],))
embedding = Embedding(input_dim=np.max(X)+1, output_dim=128)(input_layer)

conv1 = Conv1D(filters=64, kernel_size=3, activation='relu')(embedding)
pool1 = MaxPooling1D(pool_size=2)(conv1)
lstm1 = LSTM(64)(pool1)

conv2 = Conv1D(filters=64, kernel_size=5, activation='relu')(embedding)
pool2 = MaxPooling1D(pool_size=2)(conv2)
lstm2 = LSTM(64)(pool2)

conv3 = Conv1D(filters=64, kernel_size=7, activation='relu')(embedding)
pool3 = MaxPooling1D(pool_size=2)(conv3)
lstm3 = LSTM(64)(pool3)

merged = Concatenate()([lstm1, lstm2, lstm3])
dropout = Dropout(0.5)(merged)
output = Dense(num_classes, activation='softmax')(dropout)

model = Model(inputs=input_layer, outputs=output)
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.summary()

# Train model
model.fit(X_train, y_train_cat, epochs=10, batch_size=32, validation_split=0.2)

# Evaluate
y_pred = model.predict(X_test)
y_pred_labels = np.argmax(y_pred, axis=1)
y_true = y_test

labels_in_test = unique_labels(y_true, y_pred_labels)
filtered_class_names = [str(class_names[i]) for i in labels_in_test]

print("\nClassification Report:\n")
print(classification_report(y_true, y_pred_labels, labels=labels_in_test, target_names=filtered_class_names))

# Confusion Matrix
cm = confusion_matrix(y_true, y_pred_labels, labels=labels_in_test)
plt.figure(figsize=(10, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=filtered_class_names, yticklabels=filtered_class_names)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.tight_layout()
plt.savefig("conf_matrix_visualized.png")
plt.show()

# Classification Report Heatmap
report = classification_report(y_true, y_pred_labels, output_dict=True)
report_df = pd.DataFrame(report).transpose().iloc[:-3, :-1].round(2)
plt.figure(figsize=(10, 6))
sns.heatmap(report_df, annot=True, cmap="Blues", fmt=".2f")
plt.title("Classification Report Heatmap")
plt.ylabel("Class Label")
plt.xlabel("Metric")
plt.tight_layout()
plt.savefig("classification_report_heatmap.png")
plt.show()
