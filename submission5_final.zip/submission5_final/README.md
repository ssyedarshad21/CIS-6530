# Submission 5 - Deep Android Malware Detection (CODASPY '17 Inspired)

## 📄 Overview
This project implements the method proposed in the paper **"Deep Android Malware Detection" (CODASPY ’17)** using collected opcode sequences from APT malware. A hybrid CNN-LSTM model with multi-branch convolutional layers is used for classification.

---

## 📁 Folder Structure

```
submission5_final/
├── opcode_raw/                         # Raw opcode (.opcode) files from Submission 3
├── opcode_encoded/                     # Encoded .npz files after preprocessing
├── regex_tokenize_encode.py           # Script to tokenize and encode opcode files
├── cnn_lstm_model_report_visualized_fixed.py  # CNN+LSTM model + visualizations
├── confusion_matrix.png               # Saved confusion matrix heatmap
├── classification_report_heatmap.png  # Saved classification report heatmap
├── requirements.txt                   # Required Python packages
```

---

## 🧪 Model Summary
- Multi-branch CNN with 3 convolutional layers
- LSTM applied to each branch
- Concatenated + dense output layer
- Trained on stratified opcode dataset

---

## 🛠️ Setup Instructions

### 1. Create Python 3.10 environment
```bash
python3.10 -m venv dnn_env
source dnn_env/bin/activate
```

### 2. Install required packages
```bash
pip install -r requirements.txt
```

### 3. Preprocess opcode files
```bash
python regex_tokenize_encode.py
```

### 4. Train and evaluate the model
```bash
python cnn_lstm_model_report_visualized_fixed.py
```

---

## 📊 Output
- Confusion matrix and classification report are saved as `.png` images.
- Classification accuracy and f1-scores are printed and visualized.
- Results compared with classic ML models from Submission 4.

---

## 📌 Reference
- Niall McLaughlin et al., *Deep Android Malware Detection*, CODASPY ’17.
