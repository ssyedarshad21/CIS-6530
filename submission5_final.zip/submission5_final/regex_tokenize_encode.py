
import os
import re
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.preprocessing.sequence import pad_sequences
import joblib

# === CONFIG ===
RAW_DIR = "opcode_raw"
ENCODED_OUT = "../opcode_encoded"
MAX_SEQUENCE_LENGTH = 1000

os.makedirs(ENCODED_OUT, exist_ok=True)

sequences = []
labels = []
file_names = []

# === STEP 1: Tokenize opcodes with regex ===
print("[*] Tokenizing raw opcode files...")
for filename in os.listdir(RAW_DIR):
    if filename.endswith(".opcode"):
        filepath = os.path.join(RAW_DIR, filename)
        with open(filepath, "r") as f:
            text = f.read()
            opcodes = re.findall(r'\b[A-Z]+\b', text)
            sequences.append(opcodes)
            label = filename.split("_")[0]
            labels.append(label)
            file_names.append(filename)

print(f"[*] Processed {len(sequences)} files")

# === STEP 2: Encode opcodes and labels ===
print("[*] Encoding opcodes and labels...")
all_opcodes = set(op for seq in sequences for op in seq)
opcode_encoder = LabelEncoder()
opcode_encoder.fit(list(all_opcodes))

encoded_sequences = [opcode_encoder.transform(seq) for seq in sequences]
padded_sequences = pad_sequences(encoded_sequences, maxlen=MAX_SEQUENCE_LENGTH, padding='post')

label_encoder = LabelEncoder()
label_encoder.fit(labels)
encoded_labels = label_encoder.transform(labels)

# === STEP 3: Save each encoded file ===
print("[*] Saving encoded opcode sequences...")
for i in range(len(file_names)):
    out_path = os.path.join(ENCODED_OUT, file_names[i].replace(".opcode", ".npz"))
    np.savez(out_path, sequence=padded_sequences[i], label=encoded_labels[i])

# === STEP 4: Save encoders and metadata ===
print("[*] Saving encoders and metadata...")
joblib.dump(opcode_encoder, os.path.join(ENCODED_OUT, "opcode_encoder.pkl"))
joblib.dump(label_encoder, os.path.join(ENCODED_OUT, "label_encoder.pkl"))
pd.DataFrame({"filename": file_names, "label": labels}).to_csv(os.path.join(ENCODED_OUT, "file_label_map.csv"), index=False)

print("[✓] Preprocessing complete. Encoded data stored in:", ENCODED_OUT)
